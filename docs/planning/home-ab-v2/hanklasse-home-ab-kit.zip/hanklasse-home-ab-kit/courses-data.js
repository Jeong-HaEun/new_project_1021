window.HANCLASS_DEMO_COURSES = [
  {
    "id": "c002",
    "title": "XLOOKUP으로 흩어진 두 표 합치기",
    "outcome": "두 표를 합친 완성 파일 1개",
    "price": 1000,
    "category": "excel",
    "thumbnail": "assets/c002.svg"
  },
  {
    "id": "c004",
    "title": "보고서 한 장을 발표 슬라이드 3장으로 바꾸기",
    "outcome": "발표용 슬라이드 3장",
    "price": 1500,
    "category": "ppt",
    "thumbnail": "assets/c004.svg"
  },
  {
    "id": "c005",
    "title": "타깃·메시지·채널 한 장 기획표 만들기",
    "outcome": "한 장 마케팅 기획표 1개",
    "price": 1000,
    "category": "marketing-basic",
    "thumbnail": "assets/c005.svg"
  },
  {
    "id": "c003",
    "title": "광고 데이터로 주간 성과 보고서 1장 만들기",
    "outcome": "주간 광고 성과 보고서 1장",
    "price": 2000,
    "category": "marketing-practice",
    "thumbnail": "assets/c003.svg"
  },
  {
    "id": "c006",
    "title": "AI로 회의 메모를 할 일 표로 정리하기",
    "outcome": "사실 확인을 마친 할 일 표 1개",
    "price": 1500,
    "category": "ai",
    "thumbnail": "assets/c006.svg"
  },
  {
    "id": "c001",
    "title": "채용공고로 핵심 역량 찾고 내 자소서 점검하기",
    "outcome": "공고-자소서 매칭표 1장",
    "price": 1000,
    "category": "docs",
    "thumbnail": "assets/c001.svg"
  }
];
