(() => {
  const courses = window.HANCLASS_DEMO_COURSES;
  const categories = { all: '전체', excel: '엑셀', ppt: 'PPT', 'marketing-basic': '마케팅 기초', 'marketing-practice': '마케팅 실습', ai: 'AI 실습', docs: '서류 가이드' };
  let category = 'all';
  const query = document.querySelector('#query');
  const grid = document.querySelector('.course-grid');
  const dialog = document.querySelector('dialog');
  function node(tag, text, className) { const n = document.createElement(tag); if (text) n.textContent = text; if (className) n.className = className; return n; }
  function handleVariant(value) {
    const variant = value === 'B' ? 'B' : 'A';
    document.body.dataset.variant = variant;
    const art = document.querySelector('.hero-art');
    if (variant === 'A') art.src = art.dataset.src;
    else art.removeAttribute('src');
    document.querySelectorAll('[data-variant]').forEach(button => {
      if (button.tagName === 'BUTTON') button.setAttribute('aria-pressed', String(button.dataset.variant === variant));
    });
    const url = new URL(location.href); url.searchParams.set('variant', variant); history.replaceState(null, '', url);
  }
  document.querySelectorAll('button[data-variant]').forEach(button => button.addEventListener('click', () => handleVariant(button.dataset.variant)));
  function handleDetails(course) {
    dialog.querySelector('h2').textContent = course.title;
    dialog.querySelector('p').textContent = '완성 결과물 · ' + course.outcome;
    dialog.querySelector('strong').textContent = course.price.toLocaleString('ko-KR') + '원 · 제작 예정';
    dialog.showModal();
  }
  function card(course) {
    const article = node('article', null, 'course-card');
    const button = node('button', null, 'course-link'); button.type = 'button'; button.setAttribute('aria-label', course.title + ' 구성 보기');
    button.addEventListener('click', () => handleDetails(course));
    const thumb = node('div', null, 'thumbnail'); const image = node('img'); image.src = course.thumbnail; image.alt = course.outcome + ' 임시 이미지'; image.loading = 'lazy';
    thumb.append(image, node('span', '제작 예정', 'badge'));
    const body = node('div', null, 'card-body'); const outcome = node('p', null, 'outcome'); outcome.append(node('b','결과물'),document.createTextNode(course.outcome));
    const bottom = node('div', null, 'card-bottom'); bottom.append(node('span','구독 없는 개별 강의'),node('strong',course.price.toLocaleString('ko-KR')+'원'));
    body.append(node('span', categories[course.category], 'card-category'), node('h3', course.title),outcome,bottom); button.append(thumb,body);article.append(button);return article;
  }
  function render() {
    const keyword = query.value.trim().toLowerCase();
    const list = courses.filter(c => (category === 'all' || c.category === category) && (c.title+' '+c.outcome+' '+categories[c.category]).toLowerCase().includes(keyword));
    grid.replaceChildren(...list.map(card));
    document.querySelector('.count').textContent = '강의 ' + list.length + '개'; document.querySelector('.empty').hidden = list.length !== 0;
    document.querySelectorAll('[data-category]').forEach(b => b.setAttribute('aria-pressed',String(b.dataset.category === category)));
  }
  Object.entries(categories).forEach(([id,name])=>{const b=node('button',name);b.type='button';b.dataset.category=id;b.addEventListener('click',()=>{category=id;render()});document.querySelector('.filters').append(b)});
  document.querySelector('form').addEventListener('submit',event=>{event.preventDefault();render();document.querySelector('#classes').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'})});
  query.addEventListener('input',render);
  document.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
  handleVariant(new URLSearchParams(location.search).get('variant'));render();
})();
